// James Baldinger
const btnEl = document.getElementById("btn");
const resvstatus = document.getElementById("resv_status");
var resvinfo;
var firstname = document.getElementById("firstname").value;
var lastname = document.getElementById("lastname").value;
var phone = document.getElementById("phonenumber").value;
var day = document.getElementById("day").value;
var month = document.getElementById("month").value;
var time = document.getElementById("time").value;
var partysize = document.getElementById("partysize").value;

function setReservation() {
	firstname = document.getElementById("firstname").value;
	lastname = document.getElementById("lastname").value;
	phone = document.getElementById("phonenumber").value;
	day = document.getElementById("day").value;
	month = document.getElementById("month").value;
	time = document.getElementById("time").value;
	partysize = document.getElementById("partysize").value;
	
	if (!firstname || !lastname || !phone || !day || !month || !time || !partysize) {
		resvinfo = "Please fill in missing fields. ";
    } else {
		resvinfo = "Reservation for " + partysize + " set on " + month + " " + day + ".";
	}

	resvstatus.innerText = resvinfo;
}

btnEl.addEventListener("click", setReservation);
